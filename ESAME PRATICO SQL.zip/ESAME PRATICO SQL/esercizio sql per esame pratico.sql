create database Francesco;
use Francesco;

CREATE TABLE Product (
    ProductID INT PRIMARY KEY,
    ProductName VARCHAR(100),
    CategoryID INT);
    
    CREATE TABLE Region (
    RegionID INT PRIMARY KEY,
    RegionName VARCHAR(100)
);

CREATE TABLE Sales (
    SaleID INT PRIMARY KEY,
    ProductID INT,
    RegionID INT,
    SaleDate DATE,
    Quantity INT,
    Price DECIMAL(10, 2),
    FOREIGN KEY (ProductID) REFERENCES Product(ProductID),
    FOREIGN KEY (RegionID) REFERENCES Region(RegionID)
);

INSERT INTO Product (ProductID, ProductName, CategoryID) VALUES
(1, 'Top car', 1),
(2, 'Top videogame', 2),
(3, 'Table game', 3);

INSERT INTO Region (RegionID, RegionName) VALUES
(1, 'North America'),
(2, 'Europe'),
(3, 'Asia');

INSERT INTO Sales (SaleID, ProductID, RegionID, SaleDate, Quantity, Price) VALUES
(1, 1, 1, '2024-01-05', 10, 20.00),
(2, 1, 2, '2024-01-10', 8, 20.00),
(3, 2, 1, '2024-02-15', 5, 15.00),
(4, 3, 3, '2024-02-20', 3, 30.00);

SELECT COUNT(*) AS TotalProducts, COUNT(DISTINCT ProductID) AS UniqueProductIDs FROM Product;

SELECT COUNT(*) AS TotalRegions, COUNT(DISTINCT RegionID) AS UniqueRegionIDs FROM Region;

SELECT COUNT(*) AS TotalSales, COUNT(DISTINCT SaleID) AS UniqueSaleIDs FROM Sales;

SELECT p.ProductID, p.ProductName, YEAR(s.SaleDate) AS Year, SUM(s.Quantity * s.Price) AS TotalRevenue
FROM Product p
LEFT JOIN Sales s ON p.ProductID = s.ProductID
GROUP BY p.ProductID, p.ProductName, YEAR(s.SaleDate);


SELECT p.CategoryID, COUNT(*) AS TotalSales
FROM Product p
JOIN Sales s ON p.ProductID = s.ProductID
GROUP BY p.CategoryID
ORDER BY TotalSales DESC
LIMIT 1;


SELECT p.ProductID, p.ProductName, MAX(s.SaleDate) AS LastSaleDate
FROM Product p
LEFT JOIN Sales s ON p.ProductID = s.ProductID
GROUP BY p.ProductID, p.ProductName;

SELECT p.product_id, p.product_name
FROM Product p
LEFT JOIN Sales s ON p.product_id = s.product_id
WHERE s.product_id IS NULL;

SELECT product_id, product_name
FROM Product
WHERE product_id NOT IN (
    SELECT DISTINCT product_id
    FROM Sales
);




    

